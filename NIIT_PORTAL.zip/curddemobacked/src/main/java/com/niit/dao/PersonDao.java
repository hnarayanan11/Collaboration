package com.niit.dao;

import java.util.List;

import com.niit.model.Person;

public interface PersonDao {
	public List<Person> getAllPersons();
	public void addPerson(Person person);
	public void deletePerson(int id);
	Person getPerson(int id);
	public void updatePerson(Person person);
}
