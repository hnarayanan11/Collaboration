package com.niit.dao;

import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.niit.model.Person;

@Repository
@Transactional
public class PersonDaoImpl implements PersonDao{
	@Autowired
	private SessionFactory sessionFactory;
	public List<Person> getAllPersons(){
		// TODO Auto-generated method stub
		Session session=sessionFactory.openSession();
		Query query=session.createQuery("From Person");
		List<Person> person=(List<Person>) query.list();	
		System.out.println("perosn on dao impl:"+ person);
		return person;
	}
	public void addPerson(Person person) {
		// TODO Auto-generated method stub
		Session session=sessionFactory.getCurrentSession();
		session.save(person);
	}
	public void deletePerson(int id) {
		// TODO Auto-generated method stub
		Session session=sessionFactory.getCurrentSession();
		Person person=(Person)session.get(Person.class, id);//select * from person where id=?
		//if(person!=null)
			session.delete(person);//delete from person where id=?
	}
	public Person getPerson(int id) {
		// TODO Auto-generated method stub
		Session session=sessionFactory.getCurrentSession();
		Person person=(Person) session.get(Person.class, id);
		return person;
	}
	public void updatePerson(Person person) {
		// TODO Auto-generated method stub
		Session session=sessionFactory.getCurrentSession();
		session.update(person);		
	}
}
