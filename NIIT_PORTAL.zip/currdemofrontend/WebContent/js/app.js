/**
* Angular js module
*/
//declare a variable
//variable refers to the angular js  module
//1st patameter name of the module
//2nd patameter array of dependent modules - it is array
var app=angular.module("app",['ngRoute'])
app.config(function($routeProvider){
	$routeProvider
	.when('/persons',{controller:'PersonCtrl',templateUrl:'views/listofpersons.html'})
	.when('/saveperson',{controller:'PersonCtrl',templateUrl:'views/personform.html'})
	.when('/getperson/:id',{controller:'PersonDetailsCtrl',templateUrl:'views/viewperson.html'})
	.when('/getupdateform/:id',{controller:'PersonDetailsCtrl',templateUrl:'views/updateForm.html'})
	//.when('/person',{controller:'PersonCtrl',templateUrl:'views/getperson.html'})
/*	//.when('/persons',{conntroller:'personDetailsCtrl',templateUrl:'personaldetails.html'})
	.when('/students',{controller:'StudentCtrl',templateUrl:'studentdetails.html'})
	.when('/employees',{controller:'EmployeeCtrl',templateUrl:'employeedetails.html'})
	//.when('/employees',{controller:'EmployeeCtrl',templateUrl;'employeedetails.html'})
	.when('/home',{controller:'HomeCtrl',templateUrl:'home.html'})
	//.otherwise(templateUrl:'home.html')
*/})