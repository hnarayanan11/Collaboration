/**
* StudentCtrl
*/
app.controller('StudentCtrl',function($scope){
	$scope.students=[{'rollno':1,'name':'John','marks':455},
					 {'rollno':2,'name':'James','marks':390},
					 {'rollno':3,'name':'Smith','marks':250}]
})