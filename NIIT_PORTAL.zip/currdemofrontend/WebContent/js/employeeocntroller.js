/**
*  EmployeeCtrl
*/
app.controller('EmployeeCtrl',function($scope){
	$scope.employees=[{'empno':100,'empname':'SMITH','salary':10000,'dept':'HR'},
					  {'empno':100,'empname':'SMITH','salary':10000,'dept':'HR'},
					  {'empno':100,'empname':'SMITH','salary':10000,'dept':'HR'}];
})