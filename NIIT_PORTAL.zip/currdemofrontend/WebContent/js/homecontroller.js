/**
* 
*/
app.controller('HomeCtrl',function($scope){
	$scope.date=new Date();
})