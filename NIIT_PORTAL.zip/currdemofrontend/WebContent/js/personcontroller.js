/**
*perosnalDetailsCtrl
*/
app.controller('personDetailsCtrl',function($scope){
	$scope.person={"firstname":"john","lastname":"smith","email":"john.smith@abc.com","phonenumber":"039456"};//JSON representatin of person object
	$scope.welcome="Welcome message";
	$scope.today=new Date();
	$scope.number=1;
	//Array of person objects
	//JSON representation
	$scope.persons=[{'firstname':'adam','lastname':'e','email':'adam.a@xyz.com','phonenumber':'395094093'},
					{'firstname':'jack','lastname':'smith','email':'jack.smith@xyz.com','phonenumber':'9876541320'},
					{'firstname':'tom','lastname':'c','email':'tom.c@xyz.com','phonenumber':'3124658970'}]
					
	$scope.addPerson=function(){
		console.log($scope.p)//{,p.firstname,p.lastname,p.email,p.phonenumber}
		$scope.persons.push($scope.p);
	}
})