/**
 * PersonService
 * $http is a service in angular js
 * $http is used make http request
 */
app.factory('PersonService',function($http){
	var personService={} // initializatoin
	
	personService.getAllPersons=function(){
		//make rest call
		//call the middelware using $http service object
		var url="http://localhost:8083/curddemomiddleware/getallperson";
		return $http.get(url); //return the reponse to the controller
	}
	
	personService.savePerson=function(person){
		var url="http://localhost:8083/curddemomiddleware/addperson";
		return $http.post(url,person)
	}
	
	personService.deletePerson=function(id){
		var url="http://localhost:8083/curddemomiddleware/deleteperson/"+id;
		return $http['delete'](url)
	}
	
	personService.getPerson=function(id){
		var url="http://localhost:8083/curddemomiddleware/getperson/"+id;
		return $http.get(url)
	}
	
	personService.updatePerson=function(person){
		var url ="http://localhost:8083/curddemomiddleware/updateperson";
		return $http.put(url,person)
	}
	
	/*personService.getPerson=function(id){
		var url="http://localhost:8083/curddemomiddleware/getperson/"+id;
		return $http.get(url);
	}*/
	return personService; //return the object
})