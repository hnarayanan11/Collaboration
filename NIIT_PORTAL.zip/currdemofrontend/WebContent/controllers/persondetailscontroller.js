/**
 * PersonDetailsCtrl 
 * getperson/901
 * getperson/902
 */
app.controller('PersonDetailsCtrl', function($scope, PersonService, 
		$routeParams, $location) {
	var id = $routeParams.id
	// select * from person where id=?
	// $scope.person={data}

	// Satement will always gets executed
	if (id != undefined) {
		PersonService.getPerson(id).then(function(response) {
			$scope.person = response.data // result of the query select * from
											// preson where id=?
			console.log(response.status)
		}, function(response) {
			console.log(reponse.status)
		})
	}
	
	$scope.updatePerson=function(person){
		PersonService.updatePerson(person).then(function(response){
			$location.path('/getperson/' + id)
			//$location.path('/persons') //redirect the user to list of persons
			//$location.path('/getperson/'+person/id / id)
		},function(response){
			$scope.error=response.data //display the error in updateform.html
		})
	}
})