/**
 * PerosnCtrl PersonCtrl
 * PerosnService -> function($http){inititalization, funciton will get added, return the service object}
 *getallpersons/
 *savepersons
 *getpserson/:id
 *
 */
app.controller('PersonCtrl',function($scope,PersonService,$location){ //get personservice from factory
	//getAllPersons function in service
	//HttpResponse object as a result.
	//resonse - success or failure
	//success - response [Arraya of perons as datam 200 ok]
	//failuer - reponse [errorClazz as data, 404 as status code]
	//Statement - funciton call
	function getAllPersons(){//select * from person
	PersonService.getAllPersons().then(function(response){
		$scope.persons=response.data //reopnse.data is Array of Person objects
		console.log(response.data)
	},function(response){
		$scope.error=response.data //response.data is ErrorClazz obejct
		console.log(response.data)
		console.log(response.status)
	})
	}
	//callservce.then(funciton1, funciton2)
	//funciton1 - success [200 - 299] if status code is in the range
	//funciton2 - failure other status code is for error
	
	$scope.savePerson=function(person){
		PersonService.savePerson(person).then(function(response){
			//alert('person details gets inserted successfully')
			$scope.person=""
			getAllPersons()
			//$location.path('/persons')
		},function(response){
			$scope.error=response.data //ErrorClazz object
		})
	}
	
	$scope.deletePerson=function(id){
		PersonService.deletePerson(id).then(function(response){
			getAllPersons()
		},function(response){
			$scope.error=response.data;
		})
	}
	
	/*$scope.getPerson=function(id){
		PersonService.getPerson(id).then(function(response){			
			$location.path('/person')
			$scope.person=response.data
			console.log(response.data)
			console.log($scope.person)
		},function(response){
			$scope.error=response.data;
			getAllPersons()
		})
	}*/
	
	//function call
	getAllPersons()
})